import random
import csv
import urllib.request
import pandas

#data1 = csv.reader(open('data_fin.csv'), delimiter=',')
#data2 = pandas.read_csv("data_fin.csv")
data2 = pandas.read_csv("temp4.csv")

# for row in data2:
#     print(row)

# def download_web_images(url):
#     name = '9'
#     full_name = str(name) + '.jpg'
#     urllib.request.urlretrieve(url, full_name)
# download_web_images(data2["raw_url"][8])

for i in range(len(data2)):
    print(i)
    def download_web_images(url):
        name = data2["id"][i]
        full_name = str(name) + '.jpg'
        urllib.request.urlretrieve(url, full_name)
    try:
        download_web_images(data2["raw_url"][i])
    except Exception:
        pass
