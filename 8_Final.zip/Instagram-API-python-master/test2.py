#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Use text editor to edit the script and type in valid Instagram username/password

#from InstagramAPI import InstagramAPI
import pandas as pd

df_row = {}
def fill_df_row(mi,key_i):
    global df_row
    if type(mi) == type([]):
        for mi_i in mi:
            fill_df_row(mi_i,key_i)
    elif type(mi) == type({}):
        myKeys = mi.keys()
        for myKey in myKeys:
            fill_df_row(mi[myKey],myKey)
    else:
        try:
            df_row[key_i].append(mi)
        except:
            df_row[key_i] = [mi]

df = {}
def filldf(mi,key_i):
    global df
    df_i = {}
    if type(mi) == type([]):
        for mi_i in mi:
            if type(mi_i) != type({}) and type(mi_i) != type([]):
                df_i[key_i] = mi_i
            else:
                filldf(mi_i,key_i)
    elif type(mi) == type({}):
        myKeys = mi.keys()
        for myKey in myKeys:
            if type(mi[myKey]) != type({}) and type(mi[myKey]) != type([]):
                df_i[myKey] = mi[myKey]
            else:
                filldf(mi[myKey],myKey)
    df_i_key = df_i.keys()
    for dfikey in df_i_key:
        try:
            df[dfikey].append(df_i[dfikey])
        except:
            df[dfikey] = [df_i[dfikey]]
    for fullKey in df.keys():
        if fullKey in df_i_key:
            pass
        else:
            try:
                df[fullKey].append("")
            except:
                df[fullKey] = [""]

orderKey = []
def findOrderKey(mi):
    global orderKey
    if type(mi) == type({}):
        myKey = mi.keys()
        for myKey_i in myKey:
            orderKey.append(myKey_i)
        for myKey_i in myKey:
            findOrderKey(mi[myKey_i])
    elif type(mi) == type([]):
        for mi_i in mi:
            findOrderKey(mi_i)
    else:
        return 0

def main():
    from InstagramAPI import InstagramAPI
    InstagramAPI = InstagramAPI("sherry_@naver.com", "153486aa")
    InstagramAPI.login() # login
    InstagramAPI.tagFeed("잠실맛집") # get media list by tag #cat
    media_id = InstagramAPI.LastJson # last response JSON
    InstagramAPI.like(media_id["ranked_items"][0]["pk"]) # like first media
    InstagramAPI.getUserFollowers(media_id["ranked_items"][0]["user"]["pk"]) # get first media owner followers
    global df_row
    global df
    global orderKey
    fill_df_row(media_id,"key_i")
    fullKey = list(df_row.keys())
    df = {key:[] for key in fullKey}
    filldf(media_id,"key_i")
    newDF = pd.DataFrame(df)
    findOrderKey(media_id)
    newOrderKey = pd.unique(orderKey)
    newOrderKeyfin = []
    for i in newOrderKey:
        if i in newDF.columns:
            newOrderKeyfin.append(i)
    newDF_2 = pd.concat([newDF[i] for i in newOrderKeyfin],1)
    newDF_2.to_csv("D:\\Unist\\instaSort124.csv")

if __name__ == "__main__":
    main()
