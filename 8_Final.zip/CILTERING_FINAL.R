##################################
### Setting up Environment
#################################
pkgs <- c("foreach", "plyr", "stringr", "dplyr", "tm", "caret", "randomForest","nnet","kernlab","e1071")
sapply(pkgs, require, character.only = T)


raw<-read.csv("instaSort_test.csv",stringsAsFactors = F)   # raw data for test
label<-read.csv("label.csv")                               # labeling data for test
pic<-read.csv("NPD_test.csv")                              # google vision API result data for test
pic$discriminant<-ifelse(pic$discriminant==1,0,1)


# finding out seperating index
Sep<-foreach(i =1:NROW(raw),.combine=c) %do% {
  
  if(raw$organic_tracking_token[i]!=""){
    i
    }}

#################################
### extract full_name
#################################
raw_name<-c()

for(i in 1:NROW(Sep)){
     
    if(raw$full_name[(Sep[i]-2)]!=""){
      raw_name[i]<-str_c(raw$full_name[(Sep[i]-2)], collapse = ",")
    }else if(raw$full_name[(Sep[i]-4)]!=""){
     raw_name[i]<-str_c(raw$full_name[(Sep[i]-4)], collapse = ",")
    }else if(raw$full_name[(Sep[i]-5)]!=""){
      raw_name[i]<-str_c(raw$full_name[(Sep[i]-5)], collapse = ",")
    }
    else{
      raw_name[i]<-str_c(raw$full_name[(Sep[i]-6)], collapse = ",")
    }
}
raw_name

# extract nchar 
n_raw_name<-c()
for(i in 1:NROW(raw_name)){
  n_raw_name[i]<-nchar(raw_name[i])
}

a_raw_name<-ifelse(nchar(raw_name)<=11,0,1)

nn<-cbind(a_raw_name,raw_name)
nn<-data.frame(nn)
nn[nn$a_raw_name==1,]

#################################
### extract url
#################################
raw_url<-c()

raw_url[1]<-raw$url[1]
for(i in 1:(NROW(Sep)-1)){
  ifelse(raw$url[(Sep[i]+1)]=="",
    raw_url[i+1]<-raw$url[(Sep[i]+2)],raw_url[i+1]<-raw$url[(Sep[i]+1)])
  }

#################################
### extract tag
#################################
# merge every text in one board
raw2<-list()
for(i in 1:NROW(Sep)){
  if(i==1){
    raw2[1]<-str_c(raw$text[1:(Sep[1]-1)], collapse = ",")
  }else{
    raw2[i]<-str_c(raw$text[Sep[i-1]:(Sep[i]-1)], collapse = ",")
  }
}

# split by "\n" ,"#"
tag<-str_split(raw2,fixed("\n"))
tag<-str_split(tag, fixed("#"))

# delete text 
for(i in 1:length(tag)){
 tag[[i]]<-tag[[i]][-1]  
}

# extract word
for(i in 1:length(tag)){
  tag[[i]]<-word(tag[[i]],1)
}

# cleaning tag
tag <- gsub(x=tag, "[^[:alnum:]]", " ") # 함수가 사라졌으므로 gsub로 수정 
tag <- gsub(x=tag, "(\\s+|ㅋ+|ㅜ+|ㅠ+|ㅎ+)", " ") # 함수가 사라졌으므로 gsub로 수정
tag <- gsub(x=tag, "\\d+", "") ## 숫자제거 (추가)
tag <- gsub(x=tag, "\\.+", "") ## 점제거 (추가)
tag <- gsub(x=tag, "\\#+", "") ## 해시태그 제거 (추가)
tag <- gsub(x=tag, "\\ㅡ+", "") ## 대시 제거 (추가)
tag <- gsub(x=tag, "\\^+", "") ## 써컴플렉스 제거 (추가)
tag <- gsub(x=tag, "\\|+", "") ## 버티컬 바 제거 (추가)
tag <- toupper(tag) ## 대문자화 
tag <- gsub("[A-Za-z]", "", tag)
trailing_space <- "[ ]{2,}|[ ]+$"
tag <- gsub(pattern = trailing_space, replacement = "", tag)
tag <- gsub("チャ シュ", "", tag)
tag <- gsub("ラ メン", "", tag)
tag <- gsub("麻辣", "", tag)
tag <- str_split(tag," ")

unlist_tag<-unlist(tag)

# extract the number of tags
num_tag<-c()

for (i in 1:NROW(tag)){
  num_tag[i]<-NROW(tag[[i]])
}

# findng out the max length of the list
check_len <- list()

for (i in 1:length(tag)){
  check_len[i] <- length(tag[[i]])
}
max_len <- max(unlist(check_len))

# making data frame 
for(i in 1:length(tag)){
  
  if(length(tag[[i]])<max_len){
    tag[[i]][(length(tag[[i]])+1):max_len]<-"NA"
  }
}

ntag <- length(unlist(tag))
spltag <- unlist(tag)
temp <- matrix(data = spltag, nrow = max_len)
temp<-as.data.frame(temp)

################################
#   apply
#################################
# ad dictionary
bad<-read.csv("bad.csv",stringsAsFactors = F)
ad<-as.vector((t(bad)))
ad<-str_trim(ad)
ad

# find out ad
result<-foreach(i= 1:length(tag), .combine=c) %do% {
  length(intersect(ad,str_trim(tag[[i]])))/length(str_trim(tag[[i]]))
}
result<-round(result,3)

# merge the result
temp2<-cbind(t(temp),result)
temp2<-as.data.frame(temp2)
temp3<-cbind(temp2,raw_url)

# mash up columns 
rule<-cbind(label,pic=pic$discriminant,result=result,nn,url=temp3$raw_url)
rule$label<-as.factor(rule$label)
rule$pic<-as.factor(rule$pic)
rule<-rule[,1:4]

######################################
#### modeling
######################################
# cross validation
createFolds(rule$label, k=10)
create_ten_fold_cv<-function(){
  set.seed(137)
  lapply(createFolds(rule$label,k=10), function(idx){
    return(list(train=rule[-idx,],
                validation=rule[idx,]))
  })
}

folds<-create_ten_fold_cv()

# evaluation accuracy
evaluation<-function(lst){
  
  accuracy <-sapply(lst, function(one_result){
    return(sum(one_result$predicted==one_result$actual)/NROW(one_result$actual))
  })
  print(sprintf("MEAN +/- SD: %.3f +/- %.3f", mean(accuracy),sd(accuracy)))
  return(accuracy) 
}

# randomforest
rf_result<-foreach(f=folds) %do% {
  rf_model<-randomForest(label~.,data=f$train,ntree=1000)
  predicted<-predict(rf_model, newdata=f$validation, type="class")
  print(confusionMatrix(predict(rf_model, newdata=f$validation, type="class"),f$validation$label))
  return(list(actual=f$validation$label, predicted=predicted))
  }

(rf_accuracy<-evaluation(rf_result))

# neural net
nn_result<-foreach(f=folds) %do% {
  
  nn_model<-nnet(label~.,data=f$train,size=10)
  predicted<-predict(nn_model, newdata=f$validation, type="class")
  print(confusionMatrix(predict(nn_model, newdata=f$validation, type="class"),f$validation$label))
  return(list(actual=f$validation$label, predicted=predicted))
}

(nn_accuracy<-evaluation(nn_result))


# SVM
svm_result<-foreach(f=folds) %do% {
  
  svm_model<-ksvm(label~.,data=f$train)
  
  predicted<-predict(svm_model, newdata=f$validation)
  print(confusionMatrix(predict(svm_model, newdata=f$validation),f$validation$label))
  
  return(list(actual=f$validation$label, predicted=predicted))
}

(svm_accuracy<-evaluation(svm_result))

#
train.idx<-createDataPartition(rule$label, p=0.8)
data_train <-rule[train.idx,]
data_test <-rule[-train.idx, ]
(mm <- train(label ~., data=data.train,
              +             preProcess=c("pca"), method="rf", ntree=1000,
              +             trControl=trainControl(method="cv", number=10, repeats=3)))

confusionMatrix(
  +   predict(mm, newdata=data.test, type="raw"),
  +   data.test$label)



##################################
### extra
##################################
# adding tag to new dictionary

ad2=c()
ad2<-temp[which(result>0.1)]
no_ad<-temp[which(result<=0.1)]

# making additional ad dictionary 
ad2<-as.character(unique(unlist(as.list(ad2),use.names = F)))
no_ad<-as.character(unique(unlist(as.list(no_ad),use.names=F)))

# adding only ad2-no_ad with dictionary
ad3<-setdiff(ad2,no_ad)

new_ad<-str_trim(union(ad,ad3))
new_ad<-as.data.frame(new_ad)
new_ad

# extract other column
raw_refine<-raw[,9:26]
raw_refine<-raw_refine[,c("id","filter_type","like_count","comment_count")]
raw_refine<-na.omit(raw_refine)

# change filter_type to 0,1 
raw_refine$filter_type<-ifelse(raw_refine$filter_type==0,0,1)
raw_refine$filter_type<-as.numeric(raw_refine$filter_type)

# scale like count
raw_refine$like_count<-scale(raw_refine$like_count)

